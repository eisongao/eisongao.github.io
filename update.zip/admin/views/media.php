<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
 <div class="heading-bg  card-views">
  <ul class="breadcrumbs">
 <li><a href="./"><i class="fa fa-home"></i> <?php echo langs('home')?></a></li>
  <li class="active">
<?php echo langs('media_mange') ?>
  </li>
  </ul>
</div>
<?php if(isset($_GET['active_del'])):?>
<div class="actived alert alert-success alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
 <?php echo langs('deleted_ok') ?>
</div>
<?php endif;?>
<div class="row">
<?php 
$db=Database::getInstance(); 
$sql = "SELECT * FROM " . DB_PREFIX . "attachment WHERE   thumfor = 0";
	$query = $db->query($sql);	
	while ($row = $db->fetch_array($query)){
	$extension  = strtolower(substr(strrchr($row['filepath'], "."),1));
	$atturl = BLOG_URL.substr($row['filepath'], 3);
?>
<div class="col-lg-2 col-md-4 col-sm-4 col-xs-6">
<div class="panel panel-default card-view pa-0">
<div class="panel-wrapper collapse in">
<div class="panel-body pa-0">
<article class="col-item">
<div class="photo">
<div class="options">
<a href="javascript: em_confirm(<?php echo $row['aid']; ?>, 'media', '<?php echo LoginAuth::genToken(); ?>');" class="font-18 txt-grey pull-left sa-warning"><i class="zmdi zmdi-close"></i></a>
</div>
<img src="<?php if ($extension == 'zip' || $extension == 'rar'){ $imgpath = "./views/images/tar.gif"; ?><?php   echo $imgpath ?><?php }elseif (in_array($extension, array('gif', 'jpg', 'jpeg', 'png', 'bmp'))) { ?><?php echo $atturl ?><?php } ?>" class="img-responsive" style="width:78%;height:100px" alt="<?php echo $row['filename'] ?>" />
</div>
<div class="info">
<h6><?php echo $row['filename'] ?></h6>
</div>
</article>
</div>
</div>	
</div>	
</div>	
<?php } ?>
</div>
<script>	
setTimeout(hideActived,2600);				
$("#menu_action").addClass('active');
$("#menu_media").addClass('active-page');
function em_confirm (id, property, token) {
	switch (property){
	case 'media':
	var urlreturn="attachment.php?action=del_media&aid="+id;
       var msg = "<?php echo langs('attdellall') ?>";break;
}
	if(confirm(msg)){window.location = urlreturn + "&token="+token;}else {return;}
}			
</script>
