<?php
$langs = array(
//---------------------------//content/templates/default/t.php

'view_image'			=> 'Voir l\’image',
'nickname'				=> 'Pseudo',
'captcha'				=> 'Captcha',
'reply'					=> 'Répondre',

//---------------------------
//include/model/twitter_model.php
'no_permission'			=> 'Permissions insuffisantes!',

//---------------------------
//t/index.php
 'twitter_access_disabled'	=> 'Désolé, l\'accès à Discution n\'est pas activé!',
 'no_replies'				=> 'Aucunes Réponses',

);
