<?php
$langs = array(
//---------------------------
//rss.php
'post_protected_by_password'	=> 'L\'article est protégé par mot de passe.','read_more'						=> 'Lire le texte intégral&gt;&gt;',

);
