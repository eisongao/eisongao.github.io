<?php
// Langue Front View
$langs = array(
//---------------------------
//xmlrpc.php
'xmlrpc_is_off'					=> 'Astuce: le service XML-RPC du site n\'est pas activé.',
 'xmlrpc_only_post'				=> 'Erreur: le serveur XML-RPC peut accepter seulement des données des articles',
 'error_data_empty'				=> 'Erreur: les données ne peuvent pas être vides',
 'post_no_access'				=> 'Désolé, vous n\'avez pas accès à article',
 'no_posts'	 					=> 'Pas d\'article',
 'file_error'					=> 'Erreur de fichier',
 'file_name_error'				=> 'Erreur de nom de fichier',
 'file_type_error'				=> 'Erreur de type de fichier',
 'upload_folder_create_error'	=> 'Impossible de créer le répertoire de téléchargement des fichiers.',
 'upload_folder_unwritable'		=> 'Échec du téléchargement. Répertoire (Content/UploadFile) ne peut pas être écrit',
 'file_write_error'				=> 'Impossible d\'écrire dans le fichier',
 'username_password_error'		=> 'Erreur du Nom d\'utilisateur ou erreur de mot de passe',
 
 //---------------------------
//include/model/comment_model.php
 'comment_wait_approve'			=> 'Merci. Votre commentaire est en attente d\'approbation',
 'no_permission'				=> 'Autorisations insuffisantes!!',

 //---------------------------
//include/model/log_model.php
 'msg_pw'									=> 'Conseils de cryptage',
 'no_title'									=> 'sans-titre',
 'post_protected_by_password_click_title'	=> 'Cette entrée est protégée. Cliquez sur le titre et entrez le mot de passe pour accéder à cette page',
 'read_more'								=> 'Lire la suite&gt;&gt;',
 'page_password_enter'						=> 'Veuillez entrer votre mot de passe pour accéder à cette page',
 'submit_password'							=> 'Entrer',
 'back_home'								=> 'Retour à la page d\'accueil',
 
 //---------------------------
//include/model/sort_model.php
'uncategorized'=>'Uncategorized',
 
//---------------------------
//include/controller/comment_controller.php
 'comment_error_comment_disabled'	=> 'Erreur de commentaire: les commentaires pour cette entrée sont fermés',
 'comment_error_content_exists'		=> 'Erreur de commentaire: le même contenu existe déjà',
 'comment_error_flood_control'		=> 'Erreur de commentaire: vous devez attendre avant d\'envoyer un autre commentaire',
 'comment_error_name_enter'			=> 'Erreur de commentaire: s\'il vous plaît, entrez votre nom',
 'comment_error_name_invalid'		=> 'Erreur de commentaire: le nom ne répond pas aux exigences',
 'comment_error_email_invalid'		=> 'Erreur de commentaire: l\'adresse e-mail ne répond pas aux exigences',
 'comment_error_other_user'			=> 'Erreur de commentaire: les données utilisateurs ne peuvent pas être identiques à celles de l\'administrateur ou d\'autres utilisateurs',
 'comment_error_url_invalid'		=> 'Erreur de commentaire: l\'URL de la page d\'accueil n\'est pas valide',
 'comment_error_empty'				=> 'Erreur de commentaire: veuillez entrer du contenu',
 'comment_error_content_invalid'	=> 'Erreur de commentaire: Le contenu ne répond pas aux exigences',
 'comment_error_national_chars'		=> 'Erreur de commentaire: le contenu doit contenir des caractères chinois',
 'comment_error_captcha_invalid'	=> 'Erreur de commentaire: Captcha invalide',

//---------------------------
//include/lib/360webscan.php
'safe_tip'		=> 'Avertissement de sécurité',
'safe_info'		=> 'Le système de sécurité a détecté que vous essayer d\'exécuter du code dangereux et a été bloqué par le système',
'return_page'	=> 'Retour à la page',


//---------------------------
//include/lib/cache.php
 'cache_date_format'		=> 'm.Y',
 'cache_read_error'			=> 'Échec de la lecture du cache. Si vous utilisez un hôte UNIX/Linux, modifiez les autorisations du répertoire de cache (contenu/cache) et tous les dossiers à l\'intérieur de celui-ci à 777. Si vous utilisez un hôte Windows, veuillez contacter l\'administrateur et mettre tous les fichiers sous ce répertoire inscriptible',
 'cache_not_writable'		=> 'Le répertoire du cache (contenu/cache) n\'est pas accessible en écriture',

//---------------------------
//include/lib/calendar.php

 'weekday1'	=> 'Lu',
 'weekday2'	=> 'Ma',
 'weekday3'	=> 'Me',
 'weekday4'	=> 'Je',
 'weekday5'	=> 'Ve',
 'weekday6'	=> 'Sa',
 'weekday7'	=> 'Di',
 
//---------------------------------------
//include/lib/database.php
 'php_mysql_not_supported'	=> 'Le Serveur ne supporte pas PHP MySQL pour le base de données',
 
//---------------------------
//include/lib/function.base.php
 '_load_failed'					=> ' chargement raté.',
 '_bytes'						=> 'octets',
 'home'							=> 'Accueil',
 'first_page'					=> 'Premier',
 'last_page'					=> 'Dernier',
 'read_more'					=> 'Lire la suite&gt;&gt;',
'just_ago'						=> 'maintenant',
'_month_ago' 					=> 'il y a un mois',
'_year_ago'						=> 'il y\'a un an',
'_week_ago'						=> 'il y a une semaine',
'_day_ago'						=> 'il y a un jours',
'_hour_ago'						=> 'il y a des heures',
 '_sec_ago'						=> 'il y a quelques instants',
 '_min_ago'						=> 'Il ya quelques minutes',
 'file_size_exceeds_system'		=> 'La taille du fichier dépasse la limite du système',
 '_limit'						=> 'limite',
 'upload_failed_error_code'		=> 'Le téléchargement a échoué. Code d\'erreur: ',
 'file_type_not_supported'		=> 'Ce type de fichier n\'est pas supporté',
 'file_size_exceeds_'			=> 'La taille du fichier dépasse la limite',
 '_of_limit'					=> 'limite',
 'upload_folder_create_error'	=> 'Impossible de créer le répertoire de téléchargement du fichier.',
 'upload_folder_unwritable'		=> 'Le téléchargement a échoué. Le répertoire (content / uploadfile) ne peut pas être écrit.',
 '404_description'				=> 'Désolé, la page que vous avez demandée n\'existe pas',
 'prompt'						=> 'Message d\'invite',
 'click_return'					=> '&laquo;Retour',

//---------------------------
//include/lib/loginauth.php
 'captcha'					=> 'Captcha',
 'captcha_error_reenter'	=> 'Erreur de captcha. S\'il vous plaît, ré-entrer',
 'user_name_wrong_reenter'	=> 'Mauvais nom d\'utilisateur. S\'il vous plaît, entrez à nouveau',
 'password_wrong_reenter'	=> 'Mauvais mot de passe. S\'il vous plaît, entrez à nouveau.',
 'token_error'				=> 'Erreur de jeton',

//---------------------------
//include/lib/option.php
 'blogger'				=> 'Informations personnelles',
 'calendar'				=> 'Calendrier',
 'twitter_latest'		=> 'Dernieres Discutions',
 'tags'					=> 'Mot-Clefs',
 'category'				=> 'Catégorie',
 'archive'				=> 'Archive',
 'new_comments'			=> 'Derniers commentaires',
 'new_posts'			=> 'Derniers Articles',
 'random_post'			=> 'Entrée aléatoire',
 'hot_posts'			=> 'Les entrées populaires',
 'links'				=> 'Liens',
 'search'				=> 'Chercher',
 'widget_custom'		=> 'Widget personnalisé',
 'search_placeholder'	=> 'Rechercher ... et Entrer',

//---------------------------
//include/lib/view.php
 'template_not_found'	=> 'Le modèle actuel a été supprimé ou endommagé. Veuillez vous connecter en tant qu\'administrateur pour remplacer par un autre modèle',

//---------------------------------------
//include/lib/mysql.php
 'php_mysql_not_supported'	=> 'Le serveur ne supporte pas la base de données PHP MySQL',
 'db_database_unavailable'	=> 'Erreur de connexion à la base de données: le serveur de base de données ou la base de données n\'est pas disponible',
 'db_port_invalid'			=> 'Erreur de connexion à la base de données: le port de base de données n\'est pas valide',
 'db_server_unavailable'	=> 'Erreur de connexion à la base de données: le serveur de base de données est indisponible.',
 'db_credential_error'		=> 'Erreur de connexion à la base de données: nom d\'utilisateur ou mot de passe incorrect',
 'db_error_code'			=> 'Erreur de connexion à la base de données: veuillez vérifier les informations de la base de données. Code d\'erreur: ',
 'db_not_found'				=> 'Erreur de connexion à la base de données: La base de données que vous avez remplie n\'a pas été trouvée.',
 'db_sql_error'				=> 'Erreur d\'exécution de l\'instruction SQL',

//---------------------------------------
//include/lib/mysqlii.php
 'mysqli_not_supported'		=> 'Le serveur ne supporte pas l\'extension PHP MySqli',
 'db_error_name'			=> 'Erreur de connexion à la base de données: veuillez renseigner le nom de la base de données',

//---------------------------------
//include/lib/tx.php
'thank_used'			=> 'Merci pour votre utilisation de ce script',
'tx_info'				=> 'Votre navigateur actuel n\'est pas supporté, incapable d\'accéder au site!',
'lost_brower'			=> 'Votre version IE est trop vieille, veuillez tester avec un autre navigateur!',

//---------------------------
//content/templates/default/404.php
 '404_error'		=> 'Erreur - page non trouvée',
 '404_description'	=> 'Désolé, la page que vous avez demandée n\'existe pas',
 'click_return'		=> 'Retour',

//---------------------------
//content/templates/default/footer.php
 'powered_by'		=> 'Propuslé Par',
 'powered_by_emlog'	=> 'Propuslé Par Emlog',

//---------------------------
//content/templates/default/module.php
 'view_image'			=> 'Voir l\'image',
 'more'					=> 'Plus',
 'site_management'		=> 'Gestion du site',
 'logout'				=> 'Déconnexion',
 'top_posts'			=> 'Top entrées',
 'cat_top_posts'		=> 'Catégorie Top entrées',
 'edit'					=> 'Edit',
 'reply'				=> 'Répondre',
 'cancel_reply'			=> 'Annuler la réponse',
 'comment_leave'		=> 'Laisser un commentaire',
 'nickname'				=> 'Pseudo',
 'email_optional'		=> 'Adresse E-mail (facultatif)',
 'homepage_optional'	=> 'Page d\'accueil (optionnel)',
 'twitter'				=> 'Discution',
 'comments'				=> 'Commentaire',
'views'					=> 'vues ',
'text_count'			=> 'Cet article totallise ' ,
'views_count'			=> ', Merci pour votre commentaire.',
'copy_info'				=> 'Réimpression: réimpression veuillez indiquer le lien original',
'comment_count'			=> ' Commentaire.',
'login_expired'			=> 'Le Login de connexion a expiré',
'login_error'			=> ' Erreur de login de connexion',

//---------------------------
//content/templates/default/side.php
 'rss_feed'	=> 'Abonnement RSS',
 'feed_rss'	=> 'Abonnement RSS',

 'not_found'		=> 'Pas trouvé.',
 'sorry_no_results'	=> 'Désolé, aucun résultat trouvé.',
);
