<?php
// Version mobile
$langs = array(
//---------------------------
//m/index.php (All Blog/Comment/Twitter Actions)
 'mobile_version_unavailable'		=> 'La version mobile du site n\'est pas disponible.',
 'blog_entry_not_exists'			=> 'L\'entrée n\'existe pas.',
'comment_error_comment_disabled'	=> 'Erreur de commentaire: Les commentaires pour cette entrée ont été fermés',
'comment_error_content_exists'		=> 'Erreur de commentaire: le même contenu existe déjà',
'comment_error_flood_control'		=> 'Erreur de commentaire: vous devez attendre avant d\'envoyer un autre commentaire.','comment_error_name_invalid'		=> 'Erreur de commentaire: le nom ne répond pas aux exigences','comment_error_email_invalid'		=> 'Erreur de commentaire: l\'adresse e-mail ne répond pas aux exigences',
'comment_error_other_user'			=> 'Erreur de commentaire: les données utilisateur ne peuvent pas être identiques à celles de l\'administrateur ou d\'autres utilisateurs',
'comment_error_content_invalid'		=> 'Erreur de commentaire: Le contenu ne répond pas aux exigences',
'comment_error_national_chars'		=> 'Erreur de commentaire: le contenu doit contenir des caractères chinois',
'comment_error_captcha_invalid'		=> 'Erreur de commentaire: Captcha invalide',
'comment_wait_approve'				=> 'Merci. Votre commentaire est en attente d\'approbation',
'comment_parameter_error'			=> 'Erreur de paramètre',
'image_share'						=> 'Partager l\'image',
'captcha'							=> 'Captcha',
 'blog_saved_wait_approve'			=> 'Articles publiés avec succès, veuillez attendre la vérification de l\'administrateur',

//---------------------------
//m/view/header.php
'home'				=> 'Accueil',
'twitters'			=> 'Discutions',
'comments'			=> 'Commentaires',
'post_write'		=> 'Écrire un Article',
'logout'			=> 'Déconnexion',
'login'				=> 'Connexion',

//---------------------------
//m/view/log.php (Blog)
'hot'		=> 'Hot',
'post_list'	=> 'Tous les messages',
'author'	=> 'Auteur',

//---------------------------
//m/view/logauth.php
 'post_password_required'	=> 'Cet Article nécessite un mot de passe pour etre Lu. Veuillez entrer le mot de passe.',
 'ok'						=> 'OK',
'back_home'					=> '&laquo;Retour à la page d\'accueil',

//---------------------------
//m/view/login.php
'user_name'	=> 'Nom d\'utilisateur',
'password'	=> 'Mot de passe',
'log_in'	=> 'S\'identifier',

//---------------------------
//m/view/msg.php (Error Message)
 'return'		=> 'Retour ',

//---------------------------
//m/view/reply.php (add blog comment)
 'reply'					=> 'Répondre',
 'logged_as'				=> 'Vous êtes actuellement connecté en tant que',
 'nickname'					=> 'Pseudo',
 'email_optional'			=> 'Adresse E-mail (facultatif)',
 'homepage_optional'		=> 'Page d\'accueil (optionnel)',
 'content'					=> 'Contenu',
 'comment_leave'			=> 'Laisser un commentaire',

//---------------------------
//m/view/twitter.php
 'twitter_content'		=> 'Contenu de la Discution',
 'image_upload_select'	=> 'Sélectionnez une image à télécharger',
 'publish'				=> 'Publier',
 'view_image'			=> 'Voir l\'image',
 'delete'				=> 'Supprimer',

//---------------------------
//m/view/write.php (write blog)
'title'				=> 'Titre',
'category'			=> 'Catégorie',
'category_select'	=> 'Sélectionnez la catégorie ...',
'content'			=> 'Contenu',
'summary'			=> 'Résumé',
'tags'				=> 'Mots-clefs',
'post_publish'		=> 'Publier le message',

);
