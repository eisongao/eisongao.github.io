var LNG = {
//---------------------------
//admin/views/js/common.js
 'twitter_del_sure'						: 'Êtes-vous sûr de vouloir supprimer cette discution ?',
 'comment_del_sure'						: 'Êtes-vous sûr de vouloir supprimer ce commentaire ?',
 'comment_ip_del_sure'					: 'Êtes-vous sûr de vouloir supprimer tous les commentaires de cette adresse IP ?',
 'link_del_sure'						: 'Êtes-vous sûr de vouloir supprimer ce lien ?',
 'navi_del_sure'						: 'Êtes-vous sûr de vouloir supprimer cette navigation ?',
 'backup_import_sure'					: 'Êtes-vous sûr de vouloir importer les fichiers de sauvegarde ?',
 'attach_del_sure'						: 'Êtes-vous sûr de vouloir supprimer cette pièce jointe ?',
 'avatar_del_sure'						: 'Êtes-vous sûr de vouloir supprimer cet avatar ?',
 'category_del_sure'					: 'Êtes-vous sûr de vouloir supprimer cette catégorie ?',
 'page_del_sure'						: 'Êtes-vous sûr de vouloir supprimer cette page ?',
 'user_del_sure'						: 'Êtes-vous sûr de vouloir supprimer cet utilisateur ?',
 'template_del_sure'					: 'Êtes-vous sûr de vouloir supprimer le modèle par défaut ?',
 'plugin_reset_sure'					: 'Êtes-vous sûr de vouloir restaurer les paramètres du plugin par défaut? Cette opération perdra votre configuration de plug-in personnalisée.',
 'plugin_del_sure'						: 'Êtes-vous sûr de vouloir supprimer ce plugin ?',
 'title_empty'							: 'Le titre ne peut pas être vide',
 'alis_link_error'						: 'Erreur d\'alias de lien',
 'alias_invalid_chars'					: 'Alias ne doit contenir que des lettres latines, des chiffres, des traits de soulignement et des tirets',
 'alias_digital'						: 'Alias ne peut pas contenir de nombres uniquement',
 'alias_format_must_be'					: 'Alias non valide. Il ne peut pas contenir \'post\'ou \'post-digits\'',
 'alias_system_conflict'				: 'Erreur d\'alias (conflit système)',
 'wysiwyg_switch'						: 'S\'il vous plaît, passez en mode WYSIWYG',
 'click_view_fullsize'					: 'Cliquez pour afficher la taille complète',
 'alis_link_error_not_saved'			: 'Alias de lien non valide. Ne peut pas être sauvegardé automatiquement.',
 'saving'								: 'Sauver',
 'saved_ok_time'						: 'Enregistré avec succès à ',
 'save_system_error'					: 'Erreur lors de l\'enregistrement ... Impossible d\'enregistrer.',
 'title_drag'							: 'Glisser-déposer un fichier ici ou cliquez sur',
 'title_drag2'							: 'Glisser-déposer ou cliquer pour remplacer',
 'removes':'Supprimer',

//---------------------------
//include/lib/js/common_tpl.js
 'loading'								: 'Chargement...',
 'max_140_bytes'						: '(Jusqu\'à 140 caractères)',
 'nickname_empty'						: '(Le surnom ne peut pas être vide)',
 'captcha_error'						: '(Erreur de code de vérification)',
 'nickname_disabled'					: '(Ce surnom n\'est pas autorisé)',
 'nickname_exists'						: '(Ce surnom existe déjà)',
 'comments_disabled'					: '(Commentaires désactivés)',
 'comment_ok_moderation'				: '(Votre commentaire a été sauvegardé avec succès et est en attente de modération.)',
 'sliderunlock'							: 'Glisser pour déverrouiller',
 'sliderunlock_success'					: 'Débloqué avec succès',

//----------------
// The LAST key. DO NOT EDIT!!!
  '@' : '@'
};

//------------------------------
// Return the language var value
function lang(key) {
  if(LNG[key]) {
    val = LNG[key];
  } else {
    val = '{'+key+'}';
  }
  return val;
}
