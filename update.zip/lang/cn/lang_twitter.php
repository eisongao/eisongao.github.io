<?php
$langs = array(
//---------------------------//content/templates/default/t.php

'view_image'	=> '查看图片',
'nickname'	=> '昵称',
'captcha'	=> '验证码',
'reply'	=> '回复',

//---------------------------
//include/model/twitter_model.php
'no_permission'	=> '权限不足！',

//---------------------------
//t/index.php
 'twitter_access_disabled'	=> '抱歉，微语未开启前台访问！',
 'no_replies'			=> '还没有回复！',


);
