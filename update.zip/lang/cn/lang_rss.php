<?php
$langs = array(
//---------------------------
//rss.php
'post_protected_by_password'	=> '该文章已设置加密.','read_more' => '阅读全文&gt;&gt;',

);
