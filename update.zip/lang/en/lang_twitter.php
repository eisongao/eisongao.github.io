<?php
$langs = array(
//---------------------------//content/templates/default/t.php

'view_image'	=> 'View image',
'nickname'	=> 'Nicname',
'captcha'	=> 'Captcha',
'reply'	=> 'Reply',

//---------------------------
//include/model/twitter_model.php
'no_permission'	=> 'Insufficient permissions!',

//---------------------------
//t/index.php
 'twitter_access_disabled'	=> 'Sorry, twitter access is not enabled!',
 'no_replies'			=> 'No replies',

);
